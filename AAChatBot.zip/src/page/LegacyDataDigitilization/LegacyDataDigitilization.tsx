const LegacyDataDigitilization = () => {
  return <div>LegacyDataDigitilization</div>;
};

export default LegacyDataDigitilization;
